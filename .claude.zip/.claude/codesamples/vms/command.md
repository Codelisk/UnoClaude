Verwende RelayCommand für Commands
[RelayCommand]
async Task ToggleSetLocation()
{
	//TODO
}