---
uid: Uno.Extensions.Migrate.SingleProject
---

<!-- markdownlint-disable MD041 -->

> [!IMPORTANT]
> This walkthrough assumes you created your app using the Single Project template. If you used a different template, please refer to our [Migrating Projects to Single Project](xref:Uno.Development.MigratingToSingleProject) documentation.
