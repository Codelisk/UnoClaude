---
uid: Uno.Extensions.MvvmApproach
---

<!-- markdownlint-disable MD041 -->

> [!NOTE]
> This guide uses predefined code created by the Uno Template using the `Recommended` preset, however, it uses the `MVVM` approach for the examples instead of `MVUX` defined in the `Recommended` preset.
