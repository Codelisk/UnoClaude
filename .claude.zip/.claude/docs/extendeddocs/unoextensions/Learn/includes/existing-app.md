---
uid: Uno.Extensions.ExistingApp
---

<!-- markdownlint-disable MD041 -->

> [!IMPORTANT]
> If your project doesn't have any of the Uno.Extension features set up yet, check out our [Installing Extensions in an existing project](xref:Uno.Extensions.HowToGettingStarted#installing-extensions-in-an-existing-project) docs to ensure you have all the necessary setup details.
