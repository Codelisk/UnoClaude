- Open the **MainPage.cs** file.
- Replace the **`TextBlock`** with the following **`Image`** element.

    ```csharp
    new Image()
        .Width(150)
        .Height(150)
        .Source("ms-appx:///Assets/logo.png")
    ```
