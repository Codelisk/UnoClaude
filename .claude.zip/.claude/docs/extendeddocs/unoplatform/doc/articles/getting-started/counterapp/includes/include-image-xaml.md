- Open the **MainPage.xaml** file.
- Replace the **`TextBlock`** with the following **`Image`** element.

    ```xml
    <Image Width="150"
           Height="150"
           Source="Assets/logo.png" />
    ```
