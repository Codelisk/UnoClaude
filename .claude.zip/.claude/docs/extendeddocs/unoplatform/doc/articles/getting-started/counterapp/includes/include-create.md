If you're a more experienced developer, you may want to skip this tutorial and jump straight to either the [SimpleCalculator](xref:Workshop.SimpleCalc.Overview) or the [TubePlayer](xref:Workshop.TubePlayer.Overview) sample. Both are more complex and will give you a better idea of what Uno Platform can do.

## Create the Application

To get started, we're going to use the Uno Platform solution template with the simplest set of options selected. The solution template can be accessed using either Visual Studio's New Project wizard, command lines or any of the suggested IDEs below.
