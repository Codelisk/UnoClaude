## Wrap Up

At this point, you should have a working counter application. Try changing the step size and clicking the button to increment the counter.
