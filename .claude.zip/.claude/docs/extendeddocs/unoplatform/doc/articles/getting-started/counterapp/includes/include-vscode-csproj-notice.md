﻿  > [!IMPORTANT]
  > In the status bar at the bottom left of **VS Code**, ensure `Counter.csproj` is selected (by default `Counter.sln` is selected).
  >
  > ![Counter.csproj selection in Visual Studio Code](../Assets/vscode-csproj-dotnet9.0.png)
