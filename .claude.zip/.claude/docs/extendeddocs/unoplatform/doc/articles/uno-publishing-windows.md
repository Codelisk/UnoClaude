---
uid: uno.publishing.windows
---

# Publishing Your App for Windows App SDK

## Preparing For Publish

## Building your app

Using the Windows App SDK, it's possible to side-load an app using the following:

- [Build an unsigned packaged app](xref:uno.publishing.windows.sideload.packaged.unsigned)
- [Build a signed packaged app](xref:uno.publishing.windows.sideload.packaged.signed)
- [Build an unpackaged app](xref:uno.publishing.windows.sideload.unpackaged.unsigned)
