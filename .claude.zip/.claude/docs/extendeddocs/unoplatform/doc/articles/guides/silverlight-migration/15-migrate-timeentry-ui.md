---
uid: Uno.SilverlightMigration.MigrateTimeEntryUI
---

# Migrating the time entry UI

Migrate the time entry UI.

> [!NOTE]
> Work in progress.

## Next unit: Wrap-up

[![button](assets/NextButton.png)](20-wrap-up.md)
