---
uid: Uno.SilverlightMigration.ImplementTimeEntryServices
---

# Implement the time entry service

Implement the data-access services for time entry.

> [!NOTE]
> Work in progress.

## Next unit: Migrating the time entry UI

[![button](assets/NextButton.png)](15-migrate-timeentry-ui.md)
