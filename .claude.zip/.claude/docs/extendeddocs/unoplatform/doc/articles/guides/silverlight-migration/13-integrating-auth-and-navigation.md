---
uid: Uno.SilverlightMigration.IntegratingAuthAndNavigation
---

# Integrating authentication and navigation

A user should only be able to access resources to which they are authorized.

> [!NOTE]
> Work in progress.

## Next unit: Implement the time entry service

[![button](assets/NextButton.png)](14-implement-timeentry-services.md)
