---
uid: Uno.SilverlightMigration.WrapUp
---

# Wrap-up

Summarize the major lessons-learnt.

> [!NOTE]
> Work in progress.

## Next unit: Time Entry sample apps

[![button](assets/NextButton.png)](98-timeentry-samples.md)
