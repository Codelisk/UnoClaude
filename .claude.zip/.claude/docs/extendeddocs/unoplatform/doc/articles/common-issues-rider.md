---
uid: Uno.UI.CommonIssues.rider
---

# Issues related to Rider

You can view the [list of known issues in Rider's bug tracker](https://github.com/unoplatform/uno/issues/15226).
