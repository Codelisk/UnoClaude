---
uid: Uno.Development.GettingHelp
---

> [!TIP]
> Take a look at our [common issues list](xref:Uno.UI.CommonIssues) and [health status](https://aka.platform.uno/health-status) if you're having any troubles.
>
> If you are experiencing issues with Uno Platform, please visit our [GitHub Discussions](https://github.com/unoplatform/uno/discussions) or [Discord Server](https://www.platform.uno/discord) - where our engineering team and community will be able to help you.
>
