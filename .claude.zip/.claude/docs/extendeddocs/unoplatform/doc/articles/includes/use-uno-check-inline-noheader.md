## [**Windows**](#tab/windows)

[!include[use-uno-check](use-uno-check-inline-windows-noheader.md)]

## [**macOS**](#tab/macos)

[!include[use-uno-check](use-uno-check-inline-macos-noheader.md)]

## [**Linux**](#tab/linux)

[!include[use-uno-check](use-uno-check-inline-linux-noheader.md)]

---

You can find additional information about [**uno-check here**](xref:UnoCheck.UsingUnoCheck).
