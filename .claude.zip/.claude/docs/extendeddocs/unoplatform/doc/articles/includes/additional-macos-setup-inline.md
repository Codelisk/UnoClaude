In order to run Skia+GTK heads, you will need to make sure to install `gtk+3` package using the following command line, using [homebrew](https://brew.sh/):

```bash
brew install gtk+3
```
