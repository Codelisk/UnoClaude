---
uid: Uno.Contributing.Artifacts
---

# Build artifacts

- Uno publishes a new [pre-release build to NuGet](https://www.nuget.org/packages/Uno.WinUI) after every merge to master.
